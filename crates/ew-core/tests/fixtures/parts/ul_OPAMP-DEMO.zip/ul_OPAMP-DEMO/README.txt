Demo download for tests.
